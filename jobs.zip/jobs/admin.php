<?php
include 'config.php';

// Handle Add Job
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_job'])) {
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    $key_responsibilities = filter_input(INPUT_POST, 'key_responsibilities', FILTER_SANITIZE_STRING);
    $who_we_are_looking_for = filter_input(INPUT_POST, 'who_we_are_looking_for', FILTER_SANITIZE_STRING);
    $location = filter_input(INPUT_POST, 'location', FILTER_SANITIZE_STRING);
    $type = filter_input(INPUT_POST, 'type', FILTER_SANITIZE_STRING);
    $employment_type = filter_input(INPUT_POST, 'employment_type', FILTER_SANITIZE_STRING);

    if (empty($title) || empty($description) || empty($key_responsibilities) || empty($who_we_are_looking_for) || empty($location) || empty($type) || empty($employment_type)) {
        $error = "Please fill out all required fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO jobs (title, description, key_responsibilities, who_we_are_looking_for, location, type, employment_type) VALUES (:title, :description, :key_responsibilities, :who_we_are_looking_for, :location, :type, :employment_type)");
        $stmt->execute([
            ':title' => $title,
            ':description' => $description,
            ':key_responsibilities' => $key_responsibilities,
            ':who_we_are_looking_for' => $who_we_are_looking_for,
            ':location' => $location,
            ':type' => $type,
            ':employment_type' => $employment_type
        ]);
        header("Location: admin.php?success=Job+added+successfully");
        exit();
    }
}

// Handle Edit Job
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_job'])) {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    $key_responsibilities = filter_input(INPUT_POST, 'key_responsibilities', FILTER_SANITIZE_STRING);
    $who_we_are_looking_for = filter_input(INPUT_POST, 'who_we_are_looking_for', FILTER_SANITIZE_STRING);
    $location = filter_input(INPUT_POST, 'location', FILTER_SANITIZE_STRING);
    $type = filter_input(INPUT_POST, 'type', FILTER_SANITIZE_STRING);
    $employment_type = filter_input(INPUT_POST, 'employment_type', FILTER_SANITIZE_STRING);

    if (empty($title) || empty($description) || empty($key_responsibilities) || empty($who_we_are_looking_for) || empty($location) || empty($type) || empty($employment_type)) {
        $error = "Please fill out all required fields.";
    } else {
        $stmt = $conn->prepare("UPDATE jobs SET title = :title, description = :description, key_responsibilities = :key_responsibilities, who_we_are_looking_for = :who_we_are_looking_for, location = :location, type = :type, employment_type = :employment_type WHERE id = :id");
        $stmt->execute([
            ':id' => $id,
            ':title' => $title,
            ':description' => $description,
            ':key_responsibilities' => $key_responsibilities,
            ':who_we_are_looking_for' => $who_we_are_looking_for,
            ':location' => $location,
            ':type' => $type,
            ':employment_type' => $employment_type
        ]);
        header("Location: admin.php?success=Job+updated+successfully");
        exit();
    }
}

// Handle Delete Job
if (isset($_GET['delete_id'])) {
    $id = filter_input(INPUT_GET, 'delete_id', FILTER_VALIDATE_INT);
    if ($id !== false && $id !== null) {
        $stmt = $conn->prepare("DELETE FROM applications WHERE job_id = :job_id");
        $stmt->execute([':job_id' => $id]);

        $stmt = $conn->prepare("DELETE FROM jobs WHERE id = :id");
        $stmt->execute([':id' => $id]);
        header("Location: admin.php?success=Job+deleted+successfully");
        exit();
    }
}

// Fetch all jobs
$stmt = $conn->query("SELECT * FROM jobs ORDER BY created_at DESC");
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Charles Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: #2c3e50;
            color: #fff;
            padding: 20px;
            text-align: center;
            border-radius: 15px 15px 0 0;
            margin-bottom: 20px;
        }
        .header h1 {
            font-size: 2em;
        }
        .form-section, .job-list {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .form-section h2 {
            font-size: 1.5em;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        label {
            font-weight: 600;
            color: #2c3e50;
        }
        input, textarea, select {
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1em;
            width: 100%;
            transition: border-color 0.3s ease;
        }
        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: #3498db;
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        button {
            background: #3498db;
            color: #fff;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        button:hover {
            background: #2980b9;
        }
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .success {
            background: #d4edda;
            color: #155724;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
        }
        .job-list h2 {
            font-size: 1.5em;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        .job-card {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .job-card:hover {
            transform: translateY(-5px);
        }
        .job-card h3 {
            font-size: 1.3em;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        .job-card p {
            color: #666;
            margin-bottom: 10px;
        }
        .actions {
            display: flex;
            gap: 10px;
        }
        .actions a {
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            color: #fff;
            transition: background 0.3s ease;
        }
        .actions .edit {
            background: #3498db;
        }
        .actions .edit:hover {
            background: #2980b9;
        }
        .actions .delete {
            background: #e74c3c;
        }
        .actions .delete:hover {
            background: #c0392b;
        }
        @media (max-width: 768px) {
            .header h1 {
                font-size: 1.5em;
            }
            .form-section, .job-list {
                padding: 15px;
            }
            .actions {
                flex-direction: column;
                gap: 5px;
            }
            .actions a {
                width: 100%;
                text-align: center;
          
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Admin Panel - Charles Digital</h1>
        </div>

        <?php if (isset($_GET['success'])): ?>
            <div class="message success"><?php echo htmlspecialchars($_GET['success']); ?></div>
        <?php elseif (isset($error)): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Add/Edit Job Form -->
        <div class="form-section">
            <h2><?php echo isset($_GET['edit_id']) ? 'Edit Job' : 'Add New Job'; ?></h2>
            <form method="POST" action="" id="jobForm">
                <?php if (isset($_GET['edit_id'])): ?>
                    <?php
                    $edit_id = filter_input(INPUT_GET, 'edit_id', FILTER_VALIDATE_INT);
                    $stmt = $conn->prepare("SELECT * FROM jobs WHERE id = :id");
                    $stmt->execute([':id' => $edit_id]);
                    $job = $stmt->fetch(PDO::FETCH_ASSOC);
                    if (!$job) {
                        die("Job not found.");
                    }
                    ?>
                    <input type="hidden" name="id" value="<?php echo $job['id']; ?>">
                <?php endif; ?>
                <div>
                    <label for="title">Job Title <span style="color: #e74c3c;">*</span></label>
                    <input type="text" id="title" name="title" placeholder="Enter job title" value="<?php echo isset($job) ? htmlspecialchars($job['title']) : ''; ?>" required>
                </div>
                <div>
                    <label for="description">Description <span style="color: #e74c3c;">*</span></label>
                    <textarea id="description" name="description" placeholder="Enter job description" required><?php echo isset($job) ? htmlspecialchars($job['description']) : ''; ?></textarea>
                </div>
                <div>
                    <label for="key_responsibilities">Key Responsibilities <span style="color: #e74c3c;">*</span></label>
                    <textarea id="key_responsibilities" name="key_responsibilities" placeholder="Enter key responsibilities" required><?php echo isset($job) ? htmlspecialchars($job['key_responsibilities']) : ''; ?></textarea>
                </div>
                <div>
                    <label for="who_we_are_looking_for">Who We’re Looking For <span style="color: #e74c3c;">*</span></label>
                    <textarea id="who_we_are_looking_for" name="who_we_are_looking_for" placeholder="Enter who we are looking for" required><?php echo isset($job) ? htmlspecialchars($job['who_we_are_looking_for']) : ''; ?></textarea>
                </div>
                <div>
                    <label for="location">Location <span style="color: #e74c3c;">*</span></label>
                    <input type="text" id="location" name="location" placeholder="Enter location" value="<?php echo isset($job) ? htmlspecialchars($job['location']) : ''; ?>" required>
                </div>
                <div>
                    <label for="type">Job Type <span style="color: #e74c3c;">*</span></label>
                    <select id="type" name="type" required>
                        <option value="" disabled <?php echo !isset($job) ? 'selected' : ''; ?>>Select Job Type</option>
                        <option value="Project Management" <?php echo isset($job) && $job['type'] === 'Project Management' ? 'selected' : ''; ?>>Project Management</option>
                        <option value="HR" <?php echo isset($job) && $job['type'] === 'HR' ? 'selected' : ''; ?>>HR</option>
                        <option value="Software Development" <?php echo isset($job) && $job['type'] === 'Software Development' ? 'selected' : ''; ?>>Software Development</option>
                        <option value="Marketing" <?php echo isset($job) && $job['type'] === 'Marketing' ? 'selected' : ''; ?>>Marketing</option>
                    </select>
                </div>
                <div>
                    <label for="employment_type">Employment Type <span style="color: #e74c3c;">*</span></label>
                    <select id="employment_type" name="employment_type" required>
                        <option value="" disabled <?php echo !isset($job) ? 'selected' : ''; ?>>Select Employment Type</option>
                        <option value="Full-time" <?php echo isset($job) && $job['employment_type'] === 'Full-time' ? 'selected' : ''; ?>>Full-time</option>
                        <option value="Part-time" <?php echo isset($job) && $job['employment_type'] === 'Part-time' ? 'selected' : ''; ?>>Part-time</option>
                        <option value="Remote" <?php echo isset($job) && $job['employment_type'] === 'Remote' ? 'selected' : ''; ?>>Remote</option>
                    </select>
                </div>
                <button type="submit" name="<?php echo isset($_GET['edit_id']) ? 'edit_job' : 'add_job'; ?>">
                    <?php echo isset($_GET['edit_id']) ? 'Update Job' : 'Add Job'; ?>
                </button>
            </form>
        </div>

        <!-- Job List -->
        <div class="job-list">
            <h2>Job Listings</h2>
            <?php if (count($jobs) > 0): ?>
                <?php foreach ($jobs as $job): ?>
                    <div class="job-card">
                        <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                        <p><?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
                        <p><strong>Key Responsibilities:</strong> <?php echo nl2br(htmlspecialchars($job['key_responsibilities'])); ?></p>
                        <p><strong>Who We’re Looking For:</strong> <?php echo nl2br(htmlspecialchars($job['who_we_are_looking_for'])); ?></p>
                        <p><strong>Location:</strong> <?php echo htmlspecialchars($job['location']); ?></p>
                        <p><strong>Type:</strong> <?php echo htmlspecialchars($job['type']); ?></p>
                        <p><strong>Employment Type:</strong> <?php echo htmlspecialchars($job['employment_type']); ?></p>
                        <p><strong>Posted:</strong> <?php echo date('F j, Y', strtotime($job['created_at'])); ?></p>
                        <div class="actions">
                            <a href="admin.php?edit_id=<?php echo $job['id']; ?>" class="edit">Edit</a>
                            <a href="admin.php?delete_id=<?php echo $job['id']; ?>" class="delete" onclick="return confirm('Are you sure you want to delete this job and all its applications?');">Delete</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No jobs available.</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Client-side validation
        document.getElementById('jobForm').addEventListener('submit', function(e) {
            const title = document.getElementById('title').value.trim();
            const description = document.getElementById('description').value.trim();
            const keyResponsibilities = document.getElementById('key_responsibilities').value.trim();
            const whoWeAreLookingFor = document.getElementById('who_we_are_looking_for').value.trim();
            const location = document.getElementById('location').value.trim();
            const type = document.getElementById('type').value;
            const employmentType = document.getElementById('employment_type').value;

            if (!title || !description || !keyResponsibilities || !whoWeAreLookingFor || !location || !type || !employmentType) {
                e.preventDefault();
                alert('Please fill out all required fields.');
            }
        });
    </script>
</body>
</html>