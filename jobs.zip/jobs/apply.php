<?php
include 'config.php';

// Fetch job details if job ID is provided
if (isset($_GET['job_id'])) {
    $job_id = filter_input(INPUT_GET, 'job_id', FILTER_VALIDATE_INT);
    if ($job_id === false || $job_id === null) {
        die("Invalid job ID.");
    }
    $stmt = $conn->prepare("SELECT * FROM jobs WHERE id = :id");
    $stmt->execute([':id' => $job_id]);
    $job = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$job) {
        die("Job not found.");
    }
} else {
    die("Invalid job ID.");
}

// Handle form submission
$error = null;
$success = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $resume = $_FILES['resume'];

    // Validation
    if (empty($name) || empty($email) || empty($phone)) {
        $error = "Please fill out all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($resume['error'] !== UPLOAD_ERR_OK) {
        $error = "Error uploading resume. Please try again.";
    } elseif ($resume['size'] > 5 * 1024 * 1024) { // 5MB limit
        $error = "Resume file size must be less than 5MB.";
    } elseif (!in_array($resume['type'], ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'])) {
        $error = "Only PDF, DOC, and DOCX files are allowed.";
    } else {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $resumePath = $uploadDir . time() . '_' . basename($resume['name']);
        if (move_uploaded_file($resume['tmp_name'], $resumePath)) {
            $stmt = $conn->prepare("INSERT INTO applications (job_id, name, email, phone, resume_path) VALUES (:job_id, :name, :email, :phone, :resume_path)");
            $stmt->execute([
                ':job_id' => $job_id,
                ':name' => $name,
                ':email' => $email,
                ':phone' => $phone,
                ':resume_path' => $resumePath
            ]);
            $success = "Application submitted successfully! We'll get back to you soon.";
        } else {
            $error = "Error uploading resume. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for <?php echo htmlspecialchars($job['title']); ?> - Charles Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .header {
            background: #2c3e50;
            color: #fff;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            font-size: 2em;
            margin-bottom: 10px;
        }
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        .job-info {
            padding: 20px 30px;
            border-bottom: 1px solid #eee;
        }
        .job-info h2 {
            font-size: 1.5em;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        .job-info p {
            line-height: 1.6;
            margin-bottom: 10px;
        }
        .form-section {
            padding: 30px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        label {
            font-weight: 600;
            margin-bottom: 5px;
            color: #2c3e50;
        }
        input, .file-input {
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1em;
            transition: border-color 0.3s ease;
            width: 100%;
        }
        input:focus {
            outline: none;
            border-color: #3498db;
        }
        .file-input {
            padding: 8px;
        }
        .button-group {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        button, .back-button {
            padding: 14px 20px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
            text-align: center;
            text-decoration: none;
        }
        button {
            background: #3498db;
            color: #fff;
        }
        button:hover {
            background: #2980b9;
        }
        .back-button {
            background: #ccc;
            color: #333;
        }
        .back-button:hover {
            background: #bbb;
        }
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .success {
            background: #d4edda;
            color: #155724;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
        }
        @media (max-width: 600px) {
            .header h1 {
                font-size: 1.5em;
            }
            .header p {
                font-size: 1em;
            }
            .container {
                margin: 0 10px;
            }
            .job-info, .form-section {
                padding: 20px;
            }
            .button-group {
                flex-direction: column;
                gap: 10px;
            }
            button, .back-button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><?php echo htmlspecialchars($job['title']); ?></h1>
            <p>Apply Now - Join Charles Digital!</p>
        </div>
        <div class="job-info">
            <h2>Job Details</h2>
            <p><strong>Type:</strong> <?php echo htmlspecialchars($job['type']); ?></p>
            <p><strong>Employment:</strong> <?php echo htmlspecialchars($job['employment_type']); ?></p>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($job['location']); ?></p>
            <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
            <p><strong>Key Responsibilities:</strong> <?php echo nl2br(htmlspecialchars($job['key_responsibilities'])); ?></p>
            <p><strong>Who We’re Looking For:</strong> <?php echo nl2br(htmlspecialchars($job['who_we_are_looking_for'])); ?></p>
            <p><strong>Posted On:</strong> <?php echo date('F j, Y', strtotime($job['created_at'])); ?></p>
        </div>
        <div class="form-section">
            <?php if (isset($success)): ?>
                <div class="message success"><?php echo $success; ?></div>
            <?php elseif (isset($error)): ?>
                <div class="message error"><?php echo $error; ?></div>
            <?php endif; ?>
            <form method="POST" action="" enctype="multipart/form-data" id="applyForm">
                <div>
                    <label for="name">Full Name <span style="color: #e74c3c;">*</span></label>
                    <input type="text" id="name" name="name" placeholder="Enter your full name" required>
                </div>
                <div>
                    <label for="email">Email Address <span style="color: #e74c3c;">*</span></label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>
                <div>
                    <label for="phone">Phone Number <span style="color: #e74c3c;">*</span></label>
                    <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required>
                </div>
                <div>
                    <label for="resume">Upload Resume (PDF, DOC, DOCX, max 5MB) <span style="color: #e74c3c;">*</span></label>
                    <input type="file" id="resume" name="resume" class="file-input" accept=".pdf,.doc,.docx" required>
                </div>
                <div class="button-group">
                    <button type="submit">Submit Application</button>
                    <a href="index.php" class="back-button">Back to Jobs</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Client-side validation
        document.getElementById('applyForm').addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const resume = document.getElementById('resume').files[0];

            if (!name || !email || !phone || !resume) {
                e.preventDefault();
                alert('Please fill out all required fields.');
                return;
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Please enter a valid email address.');
                return;
            }

            if (resume.size > 5 * 1024 * 1024) {
                e.preventDefault();
                alert('Resume file size must be less than 5MB.');
                return;
            }

            const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
            if (!allowedTypes.includes(resume.type)) {
                e.preventDefault();
                alert('Only PDF, DOC, and DOCX files are allowed.');
                return;
            }
        });
    </script>
</body>
</html>