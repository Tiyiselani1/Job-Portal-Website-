<?php
include 'config.php';

// Fetch all jobs
$stmt = $conn->query("SELECT * FROM jobs ORDER BY created_at DESC");
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Charles Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        body {
            margin-top: 80px; /* Adjust this value based on your navbar height */
            padding-top: 50px;
        }

        .filters {
            background-color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .filters select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .job-listings {
            display: flex;
            flex-wrap: wrap;
            flex-direction: row; /* Ensure items are placed from left to right */
            justify-content: flex-start; /* Align items to the start of the container */
            gap: 20px;
            padding: 20px;
        }

        .job-card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .job-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .job-card h2 {
            margin: 0;
            color: #333;
            font-size: 1.5em;
        }

        .job-card p {
            margin: 10px 0;
            color: #666;
        }

        .job-card .details {
            margin-top: 15px;
        }

        .job-card .details span {
            display: inline-block;
            background-color: darkcyan;
            padding: 5px 10px;
            border-radius: 15px;
            margin-right: 5px;
            font-size: 0.9em;
            color: #555;
        }

        .job-card .details span.type {
            background-color: darkcyan;
            color: #fff;
        }

        .job-card .details span.employment {
            background-color: #2196F3;
            color: #fff;
        }

        .job-card .apply-button {
            display: inline-block;
            background-color: darkcyan;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 15px;
        }

        .job-card .apply-button:hover {
            background-color: cyan;
        }

        .no-jobs-message {
            text-align: center;
            width: 100%;
            font-size: 1.2em;
            color: #666;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <div class="logo">
                <img src="img/lo.png" alt="TechTalent Connect Logo" class="desktop-logo">
                <img src="img/logo3.png" class="mobile-logo">
            </div>
            <div class="hamburger" onclick="toggleMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="nav-links">
                <a href="index2.html#home">Home</a>
                <a href="index2.html#about">About Us</a>
                <a href="index2.html#features">Services</a>
                <a href="index2.html#testimonials">Success Stories</a>
                <a href="index2.html#faq">FAQ</a>
                <a href="index2.html#contact">Contact</a>
                <a href="corporate.html">Corporate</a>
                <a href="index.php">See Jobs</a>
            </div>
        </div>
    </nav>

    <div class="filters">
        <label for="job-type">Filter by Job Type:</label>
        <select id="job-type">
            <option value="all">All Positions</option>
            <option value="Project Management">Project Management</option>
            <option value="HR">HR</option>
            <option value="Software Development">Software Development</option>
            <option value="Marketing">Marketing</option>
        </select>
    </div>

    <div class="job-listings">
        <?php if (count($jobs) > 0): ?>
            <?php foreach ($jobs as $job): ?>
                <div class="job-card" data-type="<?php echo htmlspecialchars($job['type']); ?>">
                    <h2><?php echo htmlspecialchars($job['title']); ?></h2>
                    <p><?php echo htmlspecialchars($job['location']); ?></p>
                    <p><?php echo htmlspecialchars($job['description']); ?></p>
                    <div class="details">
                        <span class="type"><?php echo htmlspecialchars($job['type']); ?></span>
                        <span class="employment"><?php echo htmlspecialchars($job['employment_type']); ?></span>
                    </div>
                    <a href="apply.php?job_id=<?php echo $job['id']; ?>" class="apply-button">Apply Now</a>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-jobs-message">No jobs available at the moment.</p>
        <?php endif; ?>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Contact Info</h3>
                    <p><i class="fas fa-map-marker-alt"></i> Unit 8, Northlands Retail Park, 210 Epsom Ave, Hoogland, Randburg, 2169</p>
                    <p><i class="fas fa-phone"></i> +27 10 880 3795 </p>
                    <p><i class="fas fa-envelope"></i><a href="mailto:maluleketc9@gmail.com"> maluleketc9@gmail.com</a></p>
                    <div class="social-media">
                        <a href="#" class="social-icon linkedin">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" class="social-icon twitter">
                            <i class="fab fa-tiktok"></i>
                        </a>
                        <a href="#" class="social-icon facebook">
                            <i class="fab fa-facebook"></i>
                        </a>
                        <a href="#" class="social-icon instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                </div>
                <div class="footer-section">
                    <h3>Operating Hours</h3>
                    <p>Mon-Fri: 8:00 AM - 4:30 PM</p>
                    <p>Sat: Closed</p>
                    <p>Sun: Closed</p>
                </div>
            </div>
            <p class="footer-bottom">&copy; 2025 Charles Digital. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/main.js"></script>

    <script>
        // JavaScript for filtering jobs
        document.getElementById('job-type').addEventListener('change', function () {
            const selectedType = this.value;
            const jobCards = document.querySelectorAll('.job-card');

            jobCards.forEach(card => {
                const cardType = card.getAttribute('data-type');
                if (selectedType === 'all' || cardType === selectedType) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>