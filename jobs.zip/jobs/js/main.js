
        function toggleFAQ(element) {
            const answer = element.nextElementSibling;
            const plusSign = element.querySelector('span');
            
            answer.classList.toggle('active');
            plusSign.textContent = answer.classList.contains('active') ? '-' : '+';
        }

        function toggleMenu() {
            const navLinks = document.querySelector('.nav-links');
            const hamburger = document.querySelector('.hamburger');
            navLinks.classList.toggle('active');
            hamburger.classList.toggle('active');
        }

        function scrollToContact() {
            document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
        }

        function handleSubmit(event) {
            event.preventDefault();
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;
            
            alert(`Thank you for your message, ${name}! We will get back to you soon.`);
            event.target.reset();
        }

        // Add smooth scrolling to all nav links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
                // Close mobile menu after clicking a link
                if (window.innerWidth <= 768) {
                    const navLinks = document.querySelector('.nav-links');
                    const hamburger = document.querySelector('.hamburger');
                    navLinks.classList.remove('active');
                    hamburger.classList.remove('active');
                }
            });
        });
         document.addEventListener('DOMContentLoaded', function() {
            const slides = document.querySelectorAll('.slide');
            const dots = document.querySelectorAll('.slide-dot');
            let currentSlide = 0;
            let slideInterval;

            // Function to show a specific slide
            function showSlide(index) {
                // Remove active class from all slides and dots
                slides.forEach(slide => slide.classList.remove('active'));
                dots.forEach(dot => dot.classList.remove('active'));
                
                // Add active class to current slide and dot
                slides[index].classList.add('active');
                dots[index].classList.add('active');
                
                currentSlide = index;
            }

            // Function to show next slide
            function nextSlide() {
                currentSlide = (currentSlide + 1) % slides.length;
                showSlide(currentSlide);
            }

            // Function to start slideshow
            function startSlideshow() {
                slideInterval = setInterval(nextSlide, 5000); // Change slide every 5 seconds
            }

            // Function to stop slideshow
            function stopSlideshow() {
                clearInterval(slideInterval);
            }

            // Add click event listeners to dots
            dots.forEach((dot, index) => {
                dot.addEventListener('click', () => {
                    showSlide(index);
                    stopSlideshow();
                    startSlideshow(); // Restart the timer
                });
            });

            // Add hover pause functionality
            const slideshow = document.querySelector('.slideshow');
            slideshow.addEventListener('mouseenter', stopSlideshow);
            slideshow.addEventListener('mouseleave', startSlideshow);

            // Start the slideshow
            startSlideshow();

            // Optional: Add keyboard navigation
            document.addEventListener('keydown', (e) => {
                if (e.key === 'ArrowLeft') {
                    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
                    showSlide(currentSlide);
                    stopSlideshow();
                    startSlideshow();
                } else if (e.key === 'ArrowRight') {
                    currentSlide = (currentSlide + 1) % slides.length;
                    showSlide(currentSlide);
                    stopSlideshow();
                    startSlideshow();
                }
            });
        });